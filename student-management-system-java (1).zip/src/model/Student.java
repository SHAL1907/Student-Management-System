package model;

public class Student {
    private int id;
    private String name;
    private int age;
    private double gpa;
    private String department;

    public Student(int id, String name, int age, double gpa, String department) {
        this.id = id;
        this.name = name;
        this.age = age;
        this.gpa = gpa;
        this.department = department;
    }

    public int getId() { return id; }
    public String getName() { return name; }
    public int getAge() { return age; }
    public double getGpa() { return gpa; }
    public String getDepartment() { return department; }

    public void setName(String name) { this.name = name; }
    public void setAge(int age) { this.age = age; }
    public void setGpa(double gpa) { this.gpa = gpa; }
    public void setDepartment(String department) { this.department = department; }

    @Override
    public String toString() {
        return id + " | " + name + " | " + age + " | " + gpa + " | " + department;
    }
}
