import service.StudentService;
import model.Student;
import java.util.Scanner;

public class App {

    public static void main(String[] args) {

        StudentService service = new StudentService();
        Scanner sc = new Scanner(System.in);

        while (true) {

            System.out.println("\n1 Add Student");
            System.out.println("2 Remove Student");
            System.out.println("3 Search Student");
            System.out.println("4 List Students");
            System.out.println("5 Sort by GPA");
            System.out.println("6 Average GPA");
            System.out.println("7 Exit");

            int choice = sc.nextInt();

            switch (choice) {

                case 1:
                    System.out.print("ID: ");
                    int id = sc.nextInt();
                    sc.nextLine();

                    System.out.print("Name: ");
                    String name = sc.nextLine();

                    System.out.print("Age: ");
                    int age = sc.nextInt();

                    System.out.print("GPA: ");
                    double gpa = sc.nextDouble();
                    sc.nextLine();

                    System.out.print("Department: ");
                    String dept = sc.nextLine();

                    service.addStudent(new Student(id, name, age, gpa, dept));
                    break;

                case 2:
                    System.out.print("Enter ID: ");
                    service.removeStudent(sc.nextInt());
                    break;

                case 3:
                    System.out.print("Enter ID: ");
                    Student s = service.searchStudent(sc.nextInt());
                    System.out.println(s != null ? s : "Student not found");
                    break;

                case 4:
                    service.listStudents();
                    break;

                case 5:
                    service.sortByGPA();
                    break;

                case 6:
                    System.out.println("Average GPA: " + service.averageGPA());
                    break;

                case 7:
                    return;
            }
        }
    }
}
