package service;

import model.Student;
import java.util.*;

public class StudentService {

    private List<Student> students = new ArrayList<>();

    public void addStudent(Student student) {
        students.add(student);
        System.out.println("Student added successfully.");
    }

    public void removeStudent(int id) {
        students.removeIf(s -> s.getId() == id);
        System.out.println("Student removed.");
    }

    public Student searchStudent(int id) {
        for (Student s : students) {
            if (s.getId() == id) {
                return s;
            }
        }
        return null;
    }

    public void listStudents() {
        for (Student s : students) {
            System.out.println(s);
        }
    }

    public void sortByGPA() {
        students.sort((a, b) -> Double.compare(b.getGpa(), a.getGpa()));
        listStudents();
    }

    public double averageGPA() {
        if (students.isEmpty()) return 0;
        double total = 0;
        for (Student s : students) {
            total += s.getGpa();
        }
        return total / students.size();
    }
}
