# UML Diagram

Student
- id
- name
- age
- gpa
- department

StudentService
+ addStudent()
+ removeStudent()
+ searchStudent()
+ listStudents()
